from django.apps import AppConfig


class EmpDataConfig(AppConfig):
    name = 'emp_data'
