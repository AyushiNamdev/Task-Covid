from rest_framework import serializers
from .models import EmployeeDetails
class EmployeeDetailsSerializer(serializers.ModelSerializer):
    emp_username =serializers.CharField(max_length=200) 
    vaccine_name=serializers.CharField(max_length=999)
    dose_one_taken=serializers.BooleanField()
    dose_two_taken=serializers.BooleanField()
    dose_one=serializers.DateField()
    dose_two=serializers.DateField()
    class Meta:
        model = EmployeeDetails
        fields = ('__all__')



