from django.db import models



class EmployeeDetails(models.Model):
    emp_username = models.CharField(max_length=100, primary_key=True)
    vaccine_name = models.CharField(max_length=999)
    dose_one_taken = models.BooleanField()
    dose_two_taken = models.BooleanField()
    dose_one = models.DateField()
    dose_two = models.DateField()
