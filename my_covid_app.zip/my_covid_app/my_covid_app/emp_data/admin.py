from django.contrib import admin
from .models import EmployeeDetails


# Register your models here.

admin.site.register(EmployeeDetails)

