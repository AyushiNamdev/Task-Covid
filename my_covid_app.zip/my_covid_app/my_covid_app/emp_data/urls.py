from django.urls import path
from .views import EmployeeDetailsViews, GetDetails, SignUpView, Table, UpdateDetails

print('vvvvvv',Table.as_view())
urlpatterns = [
    path('updatedetails/employee-details/', EmployeeDetailsViews.as_view()),
    path('signup/', SignUpView.as_view(), name='signup'),
    path('details/', Table.as_view(), name='details'),
    path('employeedetail/', GetDetails.as_view(), name='employeedetail'),
    path('updatedetails/', UpdateDetails.as_view(), name='updatedetails'),
]
