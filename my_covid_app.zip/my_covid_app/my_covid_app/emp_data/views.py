import json
from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.forms import UserCreationForm
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import redirect
from .serializers import EmployeeDetailsSerializer
from .models import EmployeeDetails


class EmployeeDetailsViews(APIView):
    def post(self, request):
        data = {
            "emp_username": request.POST['username'],
            "vaccine_name": request.POST['vname'],
            "dose_one_taken": request.POST.get('firstDoseTaken', False),
            "dose_two_taken": request.POST.get('secondDoseTaken', False),
            "dose_one": request.POST['firstDoseDate'],
            "dose_two": request.POST['secondDoseDate']
        }
        if data['dose_two'] == '':
            data['dose_two'] = '2012-12-12'
        if data['dose_one'] == '':
            data['dose_one'] = '2012-12-12'

        try:
            item = EmployeeDetails.objects.get(
                emp_username=request.POST['username'])
            serializer = EmployeeDetailsSerializer(
                item, data=data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return redirect('/employeedetail')
        except BaseException:
            serializer = EmployeeDetailsSerializer(data=data)

            if serializer.is_valid():
                serializer.save()
                return redirect('/employeedetail')
            else:
                return Response({"status": "error",
                                 "data": serializer.errors},
                                status=status.HTTP_400_BAD_REQUEST)

    def get(self, request, id=None):
        if id:
            item = EmployeeDetails.objects.get(id=id)
            serializer = EmployeeDetailsSerializer(item)
            return Response({"status": "success",
                             "data": serializer.data},
                            status=status.HTTP_200_OK)

        items = EmployeeDetails.objects.all()
        serializer = EmployeeDetailsSerializer(items, many=True)
        return Response({"status": "success",
                         "data": serializer.data},
                        status=status.HTTP_200_OK)


class GetDetails(APIView):
    def get(self, request):
        items = EmployeeDetails.objects.all()
        print('itemssss',items)
        context={}
        context['rows']=items
        return render(request,'registration/details.html',context)
#
     
    # def get_details(self,serializer, **kwargs):
    
    #     return Response({"status": "success",
    #                      "data": serializer.data},
    #                     status=status.HTTP_200_OK)  

class SignUpView(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('login')
    template_name = 'signup.html'


class Details(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('details')
    template_name = 'registration/details.html'


class UpdateDetails(generic.CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy('updatedetails')
    template_name = 'registration/updatedetails.html'


class Table(generic.TemplateView):

    items = EmployeeDetails.objects.all()
    serializer = EmployeeDetailsSerializer(items, many=True)
    data = json.loads(json.dumps([i for i in serializer.data]))
    template_name = 'registration/details.html'

    def get_context_data(self, **kwargs):
        t_data = super(Table, self).get_context_data(**kwargs)
        t_data['header'] = self.data[0].keys()
        t_data['rows'] = self.data
        return t_data
